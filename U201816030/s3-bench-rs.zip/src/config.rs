use std::time::Duration;

pub const ONE_HOUR: Duration = Duration::from_secs(3600);
