Rust port of https://github.com/tylertreat/BoomFilters

- [✓] Stable Bloom Filter
- [ ] Inverse Bloom Filter
- [✓] Counting Bloom Filter
- [ ] Cuckoo Filter
- [✓] Classic Bloom Filter
- [ ] Count-Min Sketch
- [ ] Top-K
- [ ] HyperLogLog
- [ ] MinHash
